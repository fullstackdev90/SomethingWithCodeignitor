    </div> <!-- /container -->
    <link href="<?php echo base_url('bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">

        <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="<?php echo base_url('bootstrap/js/bootstrap.min.js');?>"></script>
    <script src="<?php echo base_url('bootstrap/js/docs.min.js');?>"></script>
  </body>
</html>